import { reactExports } from './__federation_shared_react-1ef963b3.js';

var jsxRuntime = {exports: {}};

var reactJsxRuntime_production_min = {};

/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f=reactExports,k=Symbol.for("react.element"),l=Symbol.for("react.fragment"),m=Object.prototype.hasOwnProperty,n=f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,p={key:!0,ref:!0,__self:!0,__source:!0};
function q(c,a,g){var b,d={},e=null,h=null;void 0!==g&&(e=""+g);void 0!==a.key&&(e=""+a.key);void 0!==a.ref&&(h=a.ref);for(b in a)m.call(a,b)&&!p.hasOwnProperty(b)&&(d[b]=a[b]);if(c&&c.defaultProps)for(b in a=c.defaultProps,a)void 0===d[b]&&(d[b]=a[b]);return {$$typeof:k,type:c,key:e,ref:h,props:d,_owner:n.current}}reactJsxRuntime_production_min.Fragment=l;reactJsxRuntime_production_min.jsx=q;reactJsxRuntime_production_min.jsxs=q;

{
  jsxRuntime.exports = reactJsxRuntime_production_min;
}

var jsxRuntimeExports = jsxRuntime.exports;

const React = window.React || globalThis.React;
const { useState, useEffect } = React;
const ChatGPTExtension = () => {
  const [config, setConfig] = useState({
    userPrompt: "",
    systemPrompt: "You are a helpful assistant.",
    temperature: 0.7,
    model: "gpt-3.5-turbo",
    maxTokens: 150
  });
  const [response, setResponse] = useState(null);
  const [isLoading, setIsLoading] = useState(false);
  const [timestamp, setTimestamp] = useState("");
  const models = [
    "gpt-3.5-turbo",
    "gpt-3.5-turbo-16k",
    "gpt-4",
    "gpt-4-turbo-preview",
    "gpt-4o",
    "gpt-4o-mini"
  ];
  useEffect(() => {
    const now = /* @__PURE__ */ new Date();
    setTimestamp(now.toLocaleString());
  }, []);
  const handleInputChange = (field, value) => {
    setConfig((prev) => ({
      ...prev,
      [field]: value
    }));
  };
  const handleSubmit = async () => {
    if (!config.userPrompt.trim()) {
      setResponse({
        success: false,
        error: "User prompt is required"
      });
      return;
    }
    setIsLoading(true);
    setResponse(null);
    try {
      const result = await ChatGPTExtension.nodeFunction(config);
      setResponse(result);
    } catch (error) {
      setResponse({
        success: false,
        error: error instanceof Error ? error.message : "Unknown error occurred"
      });
    } finally {
      setIsLoading(false);
    }
  };
  const handleClear = () => {
    setConfig({
      userPrompt: "",
      systemPrompt: "You are a helpful assistant.",
      temperature: 0.7,
      model: "gpt-3.5-turbo",
      maxTokens: 150
    });
    setResponse(null);
  };
  const containerStyle = {
    padding: "2rem",
    background: "linear-gradient(135deg, #1e40af 0%, #7c3aed 100%)",
    color: "white",
    borderRadius: "12px",
    maxWidth: "800px",
    margin: "0 auto",
    boxShadow: "0 8px 32px rgba(30, 64, 175, 0.3)",
    border: "1px solid rgba(255, 255, 255, 0.1)",
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif'
  };
  const titleStyle = {
    fontSize: "2.5rem",
    margin: "0 0 2rem 0",
    textAlign: "center",
    textShadow: "0 2px 4px rgba(0, 0, 0, 0.3)"
  };
  const formGroupStyle = {
    marginBottom: "1.5rem"
  };
  const labelStyle = {
    display: "block",
    marginBottom: "0.5rem",
    fontSize: "1.1rem",
    fontWeight: "600"
  };
  const inputStyle = {
    width: "100%",
    padding: "0.75rem",
    borderRadius: "8px",
    border: "1px solid rgba(255, 255, 255, 0.3)",
    background: "rgba(255, 255, 255, 0.1)",
    color: "white",
    fontSize: "1rem",
    backdropFilter: "blur(10px)",
    boxSizing: "border-box"
  };
  const textareaStyle = {
    ...inputStyle,
    minHeight: "100px",
    resize: "vertical"
  };
  const selectStyle = {
    ...inputStyle,
    cursor: "pointer"
  };
  const sliderContainerStyle = {
    display: "flex",
    alignItems: "center",
    gap: "1rem"
  };
  const sliderStyle = {
    flex: 1,
    height: "6px",
    borderRadius: "3px",
    background: "rgba(255, 255, 255, 0.3)",
    outline: "none",
    cursor: "pointer"
  };
  const buttonStyle = {
    background: "rgba(255, 255, 255, 0.2)",
    border: "2px solid rgba(255, 255, 255, 0.3)",
    color: "white",
    padding: "12px 24px",
    margin: "0.5rem",
    borderRadius: "25px",
    cursor: "pointer",
    fontSize: "1rem",
    fontWeight: "600",
    transition: "all 0.3s ease",
    backdropFilter: "blur(10px)"
  };
  const disabledButtonStyle = {
    ...buttonStyle,
    opacity: 0.5,
    cursor: "not-allowed"
  };
  const responseBoxStyle = {
    marginTop: "2rem",
    padding: "1.5rem",
    background: "rgba(255, 255, 255, 0.1)",
    borderRadius: "8px",
    backdropFilter: "blur(10px)",
    border: "1px solid rgba(255, 255, 255, 0.2)",
    maxHeight: "400px",
    overflowY: "auto"
  };
  const infoBoxStyle = {
    marginTop: "2rem",
    padding: "1rem",
    background: "rgba(255, 255, 255, 0.1)",
    borderRadius: "8px",
    fontSize: "0.9rem",
    backdropFilter: "blur(10px)",
    border: "1px solid rgba(255, 255, 255, 0.2)",
    textAlign: "center"
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: containerStyle, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { style: titleStyle, children: "🤖 ChatGPT Configuration" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("form", { onSubmit: (e) => {
      e.preventDefault();
      handleSubmit();
    }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: formGroupStyle, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { style: labelStyle, children: "System Prompt:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "textarea",
          {
            style: textareaStyle,
            value: config.systemPrompt,
            onChange: (e) => handleInputChange("systemPrompt", e.target.value),
            placeholder: "Set the behavior and context for the AI assistant..."
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: formGroupStyle, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { style: labelStyle, children: "User Prompt:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "textarea",
          {
            style: textareaStyle,
            value: config.userPrompt,
            onChange: (e) => handleInputChange("userPrompt", e.target.value),
            placeholder: "Enter your question or request here...",
            required: true
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: formGroupStyle, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { style: labelStyle, children: "Model:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "select",
          {
            style: selectStyle,
            value: config.model,
            onChange: (e) => handleInputChange("model", e.target.value),
            children: models.map((model) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: model, style: { background: "#1e40af", color: "white" }, children: model }, model))
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: formGroupStyle, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { style: labelStyle, children: [
          "Temperature: ",
          config.temperature
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: sliderContainerStyle, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "range",
              min: "0",
              max: "2",
              step: "0.1",
              value: config.temperature,
              onChange: (e) => handleInputChange("temperature", parseFloat(e.target.value)),
              style: sliderStyle
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "2" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("small", { style: { opacity: 0.8, fontSize: "0.85rem" }, children: "Higher values make output more random, lower values more focused" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: formGroupStyle, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { style: labelStyle, children: "Max Tokens:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "number",
            style: inputStyle,
            value: config.maxTokens,
            onChange: (e) => handleInputChange("maxTokens", parseInt(e.target.value) || 150),
            min: "1",
            max: "4000",
            placeholder: "Maximum response length (tokens)"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("small", { style: { opacity: 0.8, fontSize: "0.85rem", display: "block", marginTop: "0.25rem" }, children: "Approximate: 1 token ≈ 0.75 words" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { textAlign: "center", marginTop: "2rem" }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "submit",
            style: isLoading ? disabledButtonStyle : buttonStyle,
            disabled: isLoading,
            children: isLoading ? "🔄 Processing..." : "🚀 Send to ChatGPT"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            type: "button",
            style: buttonStyle,
            onClick: handleClear,
            disabled: isLoading,
            children: "🧹 Clear Form"
          }
        )
      ] })
    ] }),
    response && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: responseBoxStyle, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { style: { marginTop: 0, color: response.success ? "#4ade80" : "#f87171" }, children: response.success ? "✅ Response" : "❌ Error" }),
      response.success ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { marginBottom: "1rem", whiteSpace: "pre-wrap", lineHeight: 1.5 }, children: response.data?.choices?.[0]?.message?.content || "No content received" }),
        response.usage && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: {
          fontSize: "0.85rem",
          opacity: 0.8,
          borderTop: "1px solid rgba(255,255,255,0.2)",
          paddingTop: "0.5rem"
        }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Usage:" }),
          " ",
          response.usage.prompt_tokens,
          " prompt + ",
          response.usage.completion_tokens,
          " completion = ",
          response.usage.total_tokens,
          " total tokens"
        ] })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { color: "#f87171" }, children: response.error })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: infoBoxStyle, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { marginBottom: "0.5rem" }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "🔧 Extension Info:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        "ChatGPT API Integration with TypeScript + React"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { marginBottom: "0.5rem" }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "⏰ Loaded At:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        timestamp
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "🔑 API Status:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: { color: "#4ade80" }, children: "Ready to use with OPENAI_API_KEY environment variable" })
      ] })
    ] })
  ] });
};
ChatGPTExtension.nodeFunction = async (config) => {
  console.log("ChatGPTExtension nodeFunction called with config:", config);
  try {
    const apiKey = {}.OPENAI_API_KEY;
    if (!apiKey) {
      return {
        success: false,
        error: "OPENAI_API_KEY environment variable is not set"
      };
    }
    const requestBody = {
      model: config.model,
      messages: [
        {
          role: "system",
          content: config.systemPrompt
        },
        {
          role: "user",
          content: config.userPrompt
        }
      ],
      temperature: config.temperature,
      max_tokens: config.maxTokens
    };
    console.log("Making OpenAI API request:", requestBody);
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify(requestBody)
    });
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      return {
        success: false,
        error: `OpenAI API Error (${response.status}): ${errorData.error?.message || response.statusText}`
      };
    }
    const data = await response.json();
    console.log("OpenAI API response:", data);
    return {
      success: true,
      data,
      usage: data.usage
    };
  } catch (error) {
    console.error("Error in ChatGPT nodeFunction:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error occurred"
    };
  }
};

export { ChatGPTExtension as default };
