import { reactExports } from './__federation_shared_react-1ef963b3.js';

var jsxRuntime = {exports: {}};

var reactJsxRuntime_production_min = {};

/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f=reactExports,k=Symbol.for("react.element"),l=Symbol.for("react.fragment"),m=Object.prototype.hasOwnProperty,n=f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,p={key:!0,ref:!0,__self:!0,__source:!0};
function q(c,a,g){var b,d={},e=null,h=null;void 0!==g&&(e=""+g);void 0!==a.key&&(e=""+a.key);void 0!==a.ref&&(h=a.ref);for(b in a)m.call(a,b)&&!p.hasOwnProperty(b)&&(d[b]=a[b]);if(c&&c.defaultProps)for(b in a=c.defaultProps,a)void 0===d[b]&&(d[b]=a[b]);return {$$typeof:k,type:c,key:e,ref:h,props:d,_owner:n.current}}reactJsxRuntime_production_min.Fragment=l;reactJsxRuntime_production_min.jsx=q;reactJsxRuntime_production_min.jsxs=q;

{
  jsxRuntime.exports = reactJsxRuntime_production_min;
}

var jsxRuntimeExports = jsxRuntime.exports;

const React = window.React || globalThis.React;
const { useState, useEffect } = React;
const ChatGPTExtension = () => {
  const [config, setConfig] = useState({
    userPrompt: "",
    systemPrompt: "You are a helpful assistant.",
    temperature: 0.7,
    model: "gpt-4o",
    maxTokens: 1400
  });
  const models = [
    "gpt-3.5-turbo",
    "gpt-3.5-turbo-16k",
    "gpt-4",
    "gpt-4-turbo-preview",
    "gpt-4o",
    "gpt-4o-mini"
  ];
  const handleInputChange = (field, value) => {
    setConfig((prev) => ({
      ...prev,
      [field]: value
    }));
  };
  const containerStyle = {
    padding: "1rem",
    color: "#1f2937",
    borderRadius: "8px",
    height: "100%",
    width: "100%",
    margin: "0",
    border: "1px solid #e5e7eb",
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    boxSizing: "border-box",
    overflow: "auto",
    display: "flex",
    flexDirection: "column",
    gap: "0.75rem"
  };
  const formGroupStyle = {
    marginBottom: "0.75rem",
    flex: "0 0 auto"
  };
  const labelStyle = {
    display: "block",
    marginBottom: "0.25rem",
    fontSize: "clamp(0.8rem, 2.5vw, 1rem)",
    fontWeight: "600"
  };
  const inputStyle = {
    width: "100%",
    padding: "clamp(0.4rem, 1.5vw, 0.6rem)",
    borderRadius: "6px",
    border: "1px solid #d1d5db",
    background: "#ffffff",
    color: "#1f2937",
    fontSize: "clamp(0.75rem, 2vw, 0.9rem)",
    boxSizing: "border-box"
  };
  const textareaStyle = {
    ...inputStyle,
    minHeight: "clamp(60px, 15vh, 80px)",
    resize: "vertical"
  };
  const selectStyle = {
    ...inputStyle,
    cursor: "pointer"
  };
  const sliderContainerStyle = {
    display: "flex",
    alignItems: "center",
    gap: "clamp(0.5rem, 2vw, 0.75rem)",
    fontSize: "clamp(0.7rem, 1.8vw, 0.85rem)"
  };
  const sliderStyle = {
    flex: 1,
    height: "4px",
    borderRadius: "2px",
    background: "#e5e7eb",
    outline: "none",
    cursor: "pointer"
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: containerStyle, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: formGroupStyle, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { style: labelStyle, children: "System Prompt:" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "textarea",
        {
          style: textareaStyle,
          value: config.systemPrompt,
          onChange: (e) => handleInputChange("systemPrompt", e.target.value),
          placeholder: "Set the behavior and context for the AI assistant..."
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: formGroupStyle, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { style: labelStyle, children: "User Prompt:" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "textarea",
        {
          style: textareaStyle,
          value: config.userPrompt,
          onChange: (e) => handleInputChange("userPrompt", e.target.value),
          placeholder: "Enter your question or request here...",
          required: true
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: formGroupStyle, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { style: labelStyle, children: "Model:" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "select",
        {
          style: selectStyle,
          value: config.model,
          onChange: (e) => handleInputChange("model", e.target.value),
          children: models.map((model) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: model, style: { background: "#ffffff", color: "#1f2937" }, children: model }, model))
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: formGroupStyle, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { style: labelStyle, children: [
        "Temperature: ",
        config.temperature
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: sliderContainerStyle, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "0" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "range",
            min: "0",
            max: "2",
            step: "0.1",
            value: config.temperature,
            onChange: (e) => handleInputChange("temperature", parseFloat(e.target.value)),
            style: sliderStyle
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "2" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("small", { style: { opacity: 0.8, fontSize: "clamp(0.65rem, 1.5vw, 0.75rem)" }, children: "Higher values make output more random, lower values more focused" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: formGroupStyle, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { style: labelStyle, children: "Max Tokens:" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "input",
        {
          type: "number",
          style: inputStyle,
          value: config.maxTokens,
          onChange: (e) => handleInputChange("maxTokens", parseInt(e.target.value) || 150),
          min: "1",
          max: "4000",
          placeholder: "Maximum response length (tokens)"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx("small", { style: { opacity: 0.8, fontSize: "clamp(0.65rem, 1.5vw, 0.75rem)", display: "block", marginTop: "0.25rem" }, children: "Approximate: 1 token ≈ 0.75 words" })
    ] })
  ] });
};
ChatGPTExtension.nodeFunction = async (config) => {
  console.log("ChatGPTExtension nodeFunction called with config:", config);
  try {
    const apiKey = {}.OPENAI_API_KEY;
    if (!apiKey) {
      return {
        success: false,
        error: "OPENAI_API_KEY environment variable is not set"
      };
    }
    const requestBody = {
      model: config.model,
      messages: [
        {
          role: "system",
          content: config.systemPrompt
        },
        {
          role: "user",
          content: config.userPrompt
        }
      ],
      temperature: config.temperature,
      max_tokens: config.maxTokens
    };
    console.log("Making OpenAI API request:", requestBody);
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${apiKey}`
      },
      body: JSON.stringify(requestBody)
    });
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      return {
        success: false,
        error: `OpenAI API Error (${response.status}): ${errorData.error?.message || response.statusText}`
      };
    }
    const data = await response.json();
    console.log("OpenAI API response:", data);
    return {
      success: true,
      data,
      usage: data.usage
    };
  } catch (error) {
    console.error("Error in ChatGPT nodeFunction:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error occurred"
    };
  }
};

export { ChatGPTExtension as default };
