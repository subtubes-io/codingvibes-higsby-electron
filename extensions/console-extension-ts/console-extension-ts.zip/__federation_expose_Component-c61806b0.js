import { reactExports } from './index-8967cf4c.js';

var jsxRuntime = {exports: {}};

var reactJsxRuntime_production_min = {};

/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f=reactExports,k=Symbol.for("react.element"),l=Symbol.for("react.fragment"),m=Object.prototype.hasOwnProperty,n=f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,p={key:!0,ref:!0,__self:!0,__source:!0};
function q(c,a,g){var b,d={},e=null,h=null;void 0!==g&&(e=""+g);void 0!==a.key&&(e=""+a.key);void 0!==a.ref&&(h=a.ref);for(b in a)m.call(a,b)&&!p.hasOwnProperty(b)&&(d[b]=a[b]);if(c&&c.defaultProps)for(b in a=c.defaultProps,a)void 0===d[b]&&(d[b]=a[b]);return {$$typeof:k,type:c,key:e,ref:h,props:d,_owner:n.current}}reactJsxRuntime_production_min.Fragment=l;reactJsxRuntime_production_min.jsx=q;reactJsxRuntime_production_min.jsxs=q;

{
  jsxRuntime.exports = reactJsxRuntime_production_min;
}

var jsxRuntimeExports = jsxRuntime.exports;

const React = window.React || globalThis.React;
const { useState, useEffect } = React;
const ConsoleExtension = () => {
  const [logs, setLogs] = useState([
    {
      id: 1,
      timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString(),
      level: "info",
      message: "Console extension initialized"
    },
    {
      id: 2,
      timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString(),
      level: "debug",
      message: "Debug mode enabled"
    },
    {
      id: 3,
      timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString(),
      level: "warn",
      message: "This is a warning message"
    }
  ]);
  const [config, setConfig] = useState({
    maxEntries: 100,
    showTimestamps: true,
    autoScroll: true
  });
  const containerStyle = {
    padding: "2rem",
    color: "#1f2937",
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
    height: "100%",
    display: "flex",
    flexDirection: "column"
  };
  const headerStyle = {
    marginBottom: "1.5rem",
    paddingBottom: "1rem",
    borderBottom: "1px solid #e5e7eb"
  };
  const titleStyle = {
    fontSize: "1.5rem",
    fontWeight: "600",
    margin: "0 0 0.5rem 0",
    color: "#1f2937"
  };
  const subtitleStyle = {
    fontSize: "0.875rem",
    color: "#6b7280",
    margin: 0
  };
  const consoleContainerStyle = {
    flex: 1,
    background: "#f9fafb",
    border: "1px solid #e5e7eb",
    borderRadius: "8px",
    padding: "1rem",
    overflow: "auto",
    fontFamily: 'Monaco, Menlo, "Ubuntu Mono", monospace',
    fontSize: "0.875rem",
    lineHeight: "1.5",
    minHeight: "200px",
    maxHeight: "300px"
  };
  const logEntryStyle = (level) => {
    const baseStyle = {
      padding: "0.25rem 0",
      borderBottom: "1px solid #f3f4f6",
      display: "flex",
      alignItems: "flex-start",
      gap: "0.5rem"
    };
    const levelColors = {
      info: "#3b82f6",
      warn: "#f59e0b",
      error: "#ef4444",
      debug: "#6b7280"
    };
    return {
      ...baseStyle,
      color: levelColors[level] || "#1f2937"
    };
  };
  const timestampStyle = {
    color: "#9ca3af",
    fontSize: "0.75rem",
    minWidth: "80px",
    fontWeight: "500"
  };
  const levelBadgeStyle = (level) => {
    const levelStyles = {
      info: { bg: "#dbeafe", color: "#1e40af" },
      warn: { bg: "#fef3c7", color: "#92400e" },
      error: { bg: "#fee2e2", color: "#991b1b" },
      debug: { bg: "#f3f4f6", color: "#374151" }
    };
    const style = levelStyles[level] || levelStyles.info;
    return {
      background: style.bg,
      color: style.color,
      padding: "0.125rem 0.5rem",
      borderRadius: "12px",
      fontSize: "0.75rem",
      fontWeight: "500",
      textTransform: "uppercase",
      minWidth: "50px",
      textAlign: "center"
    };
  };
  const messageStyle = {
    flex: 1,
    wordBreak: "break-word"
  };
  const controlsStyle = {
    marginTop: "1rem",
    display: "flex",
    gap: "0.5rem",
    flexWrap: "wrap"
  };
  const buttonStyle = {
    padding: "0.5rem 1rem",
    backgroundColor: "#3b82f6",
    color: "white",
    border: "none",
    borderRadius: "6px",
    cursor: "pointer",
    fontSize: "0.875rem",
    fontWeight: "500"
  };
  const clearButtonStyle = {
    ...buttonStyle,
    backgroundColor: "#ef4444"
  };
  const addLog = (level, message) => {
    const newLog = {
      id: logs.length + 1,
      timestamp: (/* @__PURE__ */ new Date()).toLocaleTimeString(),
      level,
      message
    };
    setLogs((prevLogs) => {
      const updatedLogs = [...prevLogs, newLog];
      if (updatedLogs.length > config.maxEntries) {
        return updatedLogs.slice(-config.maxEntries);
      }
      return updatedLogs;
    });
  };
  const clearLogs = () => {
    setLogs([]);
  };
  const addInfoLog = () => addLog("info", `Info message at ${( new Date()).toLocaleTimeString()}`);
  const addWarningLog = () => addLog("warn", "This is a warning message");
  const addErrorLog = () => addLog("error", "An error has occurred");
  const addDebugLog = () => addLog("debug", `Debug info: ${Math.random().toString(36).substr(2, 9)}`);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: containerStyle, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: headerStyle, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { style: titleStyle, children: "Console Output" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: subtitleStyle, children: "System logs and debugging information" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: consoleContainerStyle, children: logs.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { color: "#9ca3af", textAlign: "center", padding: "2rem" }, children: "No log entries yet" }) : logs.map((log) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: logEntryStyle(log.level), children: [
      config.showTimestamps && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: timestampStyle, children: log.timestamp }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: levelBadgeStyle(log.level), children: log.level }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: messageStyle, children: log.message })
    ] }, log.id)) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: controlsStyle, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: addInfoLog, style: buttonStyle, children: "Add Info" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: addWarningLog, style: { ...buttonStyle, backgroundColor: "#f59e0b" }, children: "Add Warning" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: addErrorLog, style: { ...buttonStyle, backgroundColor: "#ef4444" }, children: "Add Error" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: addDebugLog, style: { ...buttonStyle, backgroundColor: "#6b7280" }, children: "Add Debug" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: clearLogs, style: clearButtonStyle, children: "Clear All" })
    ] })
  ] });
};
ConsoleExtension.nodeFunction = async (config) => {
  console.log("ConsoleExtension nodeFunction called with config:", config);
  try {
    return {
      success: true,
      data: {
        message: "Console configuration updated",
        config,
        timestamp: (/* @__PURE__ */ new Date()).toISOString()
      }
    };
  } catch (error) {
    console.error("Error in Console nodeFunction:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error occurred"
    };
  }
};

export { ConsoleExtension as default };
