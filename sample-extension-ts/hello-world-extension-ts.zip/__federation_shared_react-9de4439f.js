export { index as default } from './index-8967cf4c.js';
