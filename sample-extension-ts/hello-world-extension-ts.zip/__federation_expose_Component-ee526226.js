import { reactExports } from './index-8967cf4c.js';

var jsxRuntime = {exports: {}};

var reactJsxRuntime_production_min = {};

/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f=reactExports,k=Symbol.for("react.element"),l=Symbol.for("react.fragment"),m=Object.prototype.hasOwnProperty,n=f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,p={key:!0,ref:!0,__self:!0,__source:!0};
function q(c,a,g){var b,d={},e=null,h=null;void 0!==g&&(e=""+g);void 0!==a.key&&(e=""+a.key);void 0!==a.ref&&(h=a.ref);for(b in a)m.call(a,b)&&!p.hasOwnProperty(b)&&(d[b]=a[b]);if(c&&c.defaultProps)for(b in a=c.defaultProps,a)void 0===d[b]&&(d[b]=a[b]);return {$$typeof:k,type:c,key:e,ref:h,props:d,_owner:n.current}}reactJsxRuntime_production_min.Fragment=l;reactJsxRuntime_production_min.jsx=q;reactJsxRuntime_production_min.jsxs=q;

{
  jsxRuntime.exports = reactJsxRuntime_production_min;
}

var jsxRuntimeExports = jsxRuntime.exports;

const React = window.React || globalThis.React;
const { useState, useEffect } = React;
const HelloWorldExtension = () => {
  const [greeting, setGreeting] = useState("Hello, World!");
  const [timestamp, setTimestamp] = useState("");
  const [clickCount, setClickCount] = useState(0);
  useEffect(() => {
    const now = /* @__PURE__ */ new Date();
    setTimestamp(now.toLocaleString());
  }, []);
  const handleGreetingChange = () => {
    const greetings = [
      "Hello, World! 👋",
      "Hello from TypeScript! 🎯",
      "Greetings from the Extension! 🚀",
      "TypeScript + React = ❤️",
      "Dynamic Loading Success! ✨"
    ];
    const randomGreeting = greetings[Math.floor(Math.random() * greetings.length)];
    setGreeting(randomGreeting);
    setClickCount((prev) => prev + 1);
  };
  const containerStyle = {
    padding: "2rem",
    textAlign: "center",
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    color: "white",
    borderRadius: "12px",
    maxWidth: "500px",
    margin: "0 auto",
    boxShadow: "0 8px 32px rgba(102, 126, 234, 0.3)",
    border: "1px solid rgba(255, 255, 255, 0.1)"
  };
  const titleStyle = {
    fontSize: "2.5rem",
    margin: "0 0 1rem 0",
    textShadow: "0 2px 4px rgba(0, 0, 0, 0.3)"
  };
  const greetingStyle = {
    fontSize: "1.5rem",
    margin: "1.5rem 0",
    padding: "1rem",
    background: "rgba(255, 255, 255, 0.1)",
    borderRadius: "8px",
    backdropFilter: "blur(10px)",
    border: "1px solid rgba(255, 255, 255, 0.2)"
  };
  const buttonStyle = {
    background: "rgba(255, 255, 255, 0.2)",
    border: "2px solid rgba(255, 255, 255, 0.3)",
    color: "white",
    padding: "12px 24px",
    margin: "1rem",
    borderRadius: "25px",
    cursor: "pointer",
    fontSize: "1rem",
    fontWeight: "600",
    transition: "all 0.3s ease",
    backdropFilter: "blur(10px)"
  };
  const infoBoxStyle = {
    marginTop: "2rem",
    padding: "1rem",
    background: "rgba(255, 255, 255, 0.1)",
    borderRadius: "8px",
    fontSize: "0.9rem",
    backdropFilter: "blur(10px)",
    border: "1px solid rgba(255, 255, 255, 0.2)"
  };
  const handleMouseOver = (e) => {
    e.currentTarget.style.background = "rgba(255, 255, 255, 0.3)";
    e.currentTarget.style.transform = "translateY(-2px)";
    e.currentTarget.style.boxShadow = "0 4px 12px rgba(0, 0, 0, 0.2)";
  };
  const handleMouseOut = (e) => {
    e.currentTarget.style.background = "rgba(255, 255, 255, 0.2)";
    e.currentTarget.style.transform = "translateY(0)";
    e.currentTarget.style.boxShadow = "none";
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: containerStyle, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { style: titleStyle, children: "🎉 Hello World Extension" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: { margin: "0 0 1.5rem 0", opacity: 0.9 }, children: "Built with TypeScript + React + Webpack" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: greetingStyle, children: greeting }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        style: buttonStyle,
        onClick: handleGreetingChange,
        onMouseOver: handleMouseOver,
        onMouseOut: handleMouseOut,
        type: "button",
        children: "Change Greeting"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: infoBoxStyle, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { marginBottom: "0.5rem" }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "🔧 Tech Stack:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        "TypeScript + React + Webpack + UMD"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { marginBottom: "0.5rem" }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "⏰ Loaded At:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        timestamp
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { marginBottom: "0.5rem" }, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "👆 Interactions:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        clickCount,
        " clicks"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "🚀 Status:" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("br", {}),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: { color: "#4ade80" }, children: "✅ Successfully Loaded!" })
      ] })
    ] })
  ] });
};
HelloWorldExtension.nodeFunction = () => {
  console.log("HelloWorldExtension nodeFunction called");
  return {
    name: "hello-world-extension",
    version: "1.0.0",
    capabilities: ["greeting", "interaction-counter"],
    initialize: () => {
      console.log("HelloWorldExtension initialized");
    },
    cleanup: () => {
      console.log("HelloWorldExtension cleanup");
    }
  };
};

export { HelloWorldExtension as default };
