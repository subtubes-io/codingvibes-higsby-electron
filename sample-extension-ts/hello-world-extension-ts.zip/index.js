import { jsxs as t, jsx as e } from "react/jsx-runtime";
import { useState as n, useEffect as p } from "react";
const v = () => {
  const [o, a] = n("Hello, World!"), [i, l] = n(""), [d, s] = n(0);
  return p(() => {
    l((/* @__PURE__ */ new Date()).toLocaleString());
  }, []), /* @__PURE__ */ t("div", { style: {
    padding: "2rem",
    textAlign: "center",
    background: "linear-gradient(135deg, #667eea 0%, #764ba2 100%)",
    color: "white",
    borderRadius: "12px",
    maxWidth: "500px",
    margin: "0 auto",
    boxShadow: "0 8px 32px rgba(102, 126, 234, 0.3)",
    border: "1px solid rgba(255, 255, 255, 0.1)"
  }, children: [
    /* @__PURE__ */ e("h1", { style: {
      fontSize: "2.5rem",
      margin: "0 0 1rem 0",
      textShadow: "0 2px 4px rgba(0, 0, 0, 0.3)"
    }, children: "🎉 Hello World Extension" }),
    /* @__PURE__ */ e("p", { style: { margin: "0 0 1.5rem 0", opacity: 0.9 }, children: "Built with TypeScript + React + Webpack" }),
    /* @__PURE__ */ e("div", { style: {
      fontSize: "1.5rem",
      margin: "1.5rem 0",
      padding: "1rem",
      background: "rgba(255, 255, 255, 0.1)",
      borderRadius: "8px",
      backdropFilter: "blur(10px)",
      border: "1px solid rgba(255, 255, 255, 0.2)"
    }, children: o }),
    /* @__PURE__ */ e(
      "button",
      {
        style: {
          background: "rgba(255, 255, 255, 0.2)",
          border: "2px solid rgba(255, 255, 255, 0.3)",
          color: "white",
          padding: "12px 24px",
          margin: "1rem",
          borderRadius: "25px",
          cursor: "pointer",
          fontSize: "1rem",
          fontWeight: "600",
          transition: "all 0.3s ease",
          backdropFilter: "blur(10px)"
        },
        onClick: () => {
          const r = [
            "Hello, World! 👋",
            "Hello from TypeScript! 🎯",
            "Greetings from the Extension! 🚀",
            "TypeScript + React = ❤️",
            "Dynamic Loading Success! ✨"
          ], c = r[Math.floor(Math.random() * r.length)];
          a(c), s((g) => g + 1);
        },
        onMouseOver: (r) => {
          r.currentTarget.style.background = "rgba(255, 255, 255, 0.3)", r.currentTarget.style.transform = "translateY(-2px)", r.currentTarget.style.boxShadow = "0 4px 12px rgba(0, 0, 0, 0.2)";
        },
        onMouseOut: (r) => {
          r.currentTarget.style.background = "rgba(255, 255, 255, 0.2)", r.currentTarget.style.transform = "translateY(0)", r.currentTarget.style.boxShadow = "none";
        },
        type: "button",
        children: "Change Greeting"
      }
    ),
    /* @__PURE__ */ t("div", { style: {
      marginTop: "2rem",
      padding: "1rem",
      background: "rgba(255, 255, 255, 0.1)",
      borderRadius: "8px",
      fontSize: "0.9rem",
      backdropFilter: "blur(10px)",
      border: "1px solid rgba(255, 255, 255, 0.2)"
    }, children: [
      /* @__PURE__ */ t("div", { style: { marginBottom: "0.5rem" }, children: [
        /* @__PURE__ */ e("strong", { children: "🔧 Tech Stack:" }),
        /* @__PURE__ */ e("br", {}),
        "TypeScript + React + Webpack + UMD"
      ] }),
      /* @__PURE__ */ t("div", { style: { marginBottom: "0.5rem" }, children: [
        /* @__PURE__ */ e("strong", { children: "⏰ Loaded At:" }),
        /* @__PURE__ */ e("br", {}),
        i
      ] }),
      /* @__PURE__ */ t("div", { style: { marginBottom: "0.5rem" }, children: [
        /* @__PURE__ */ e("strong", { children: "👆 Interactions:" }),
        /* @__PURE__ */ e("br", {}),
        d,
        " clicks"
      ] }),
      /* @__PURE__ */ t("div", { children: [
        /* @__PURE__ */ e("strong", { children: "🚀 Status:" }),
        /* @__PURE__ */ e("br", {}),
        /* @__PURE__ */ e("span", { style: { color: "#4ade80" }, children: "✅ Successfully Loaded!" })
      ] })
    ] })
  ] });
};
export {
  v as default
};
