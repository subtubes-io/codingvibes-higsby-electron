import React from 'react';
declare const HelloWorldExtension: React.FC;
export default HelloWorldExtension;
